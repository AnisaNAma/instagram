<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🆂🅶 🅶🆁🅰🅼</title>
    <link rel="shortcut icon" href="/insta/data/logo.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        body{
      margin: 0;
      padding: 0;
      background: url(/insta/data/totoro.jpg) no-repeat;
      
      font-family: sans-serif;
      background-size: cover;
      background-repeat: no-repeat ;
      background-attachment: fixed;
      background-position: center;
    }
        .geeks {
            width: 600px;
            height: 300px;
            overflow: hidden;
            margin: 0 auto;
        }

        .geeks img {
            width:100%;
            transition: 0.5s all ease-in-out;
        }

        .geeks:hover img {
            transform:scale(1.5);
        }
    </style>
</head>
<body>
<br>
<center>
  <nav class="navbar fixed-top navbar-expand-lg fixed-top" style="background-color:#B0D9B1;">
  <div class="container-fluid">
  <a class = "navbar-brand" href = "#">
  <img src = "/insta/data/logo.png" width="60" height = "60">
  🆂🅶 🅶🆁🅰🅼
  </a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <nav class="navbar">
  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cloud-plus-fill" viewBox="0 0 16 16">
  <path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm.5 4v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 1 0z"/>
</svg>
</button><ul></ul>
  <nav class="navbar">
  <a href="logout.php"><button class="btn btn-danger">
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm4.5 5.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
</svg>
</button>
  </a>
  </div>
  </nav>
  <br>
      <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header" style="background-color: #B0D9B1;">
        <h1 class="modal-title fs-5 text-white" id="exampleModalLabel" >Tambah 🆂🅶 🅶🆁🅰🅼</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" ></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
      <label for="" class="form-label">Foto</label>
    <input type="file" class="form-control" name="foto" id="" required><br>
    <label for="" class="form-label">Caption</label><br>
    <input type="" class="form-control" name="caption" id="" autocomplete="off"><br>
    <label for="" class="form-label">Lokasi</label><br>
    <input type="" class="form-control" name="lokasi" id="" autocomplete="off"><br>

</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <input type="submit" class="btn btn-primary" value="Tambah" name="Posting"></button>
</form>
      </div>
    </div>
  </div>
</div>
<!-- modal2 -->
<!-- Button trigger modal -->
  
    <div class="container">
      <?php
      $sql = "SELECT * FROM post ORDER BY no DESC";
      $query = mysqli_query($koneksi, $sql);

  while($post = mysqli_fetch_assoc($query)) : ?>

    <br><div class="card  mt-3" style="width: 40rem;">
    <div class="geeks">
    <img class="card-img-top" src="data/<?= $post['foto'] ?>" alt="Card image cap">
    </div>
    <div class="card-body">
    </div>
        
    <ul class="list-group list-group-flush">
    <li class="list-group-item"><?= $post['caption'] ?></li>
    <li class="list-group-item"><?= $post['lokasi'] ?></li>
    </ul>
    <div class="card-body">

    <a href="hapus.php?no=<?= $post['no'] ?>" style="font-size:20px; background: none; color:primary; border-radius: 100px;border:none;"><i class="btn btn-danger fa fa-trash"></i></a>
    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$post['no']?>"><i class="btn btn-success fa fa-pencil"></i></button>
    </div>
    </div>
    <br>
   


    </div>
 


<!-- Modal -->

<div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #B0D9B1;">
        <h2 class="modal-title fs-5 text-white" id="staticBackdropLabel" >Edit 🆂🅶 🅶🆁🅰🅼</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <div class="container" align="left">
        <label for="">Images</label>
        

        <div align="left">
        <img src="data/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="file" name="foto" class="form-control" value="<?= $post['foto'] ?>" ><br>
        </div>

       
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
        

       
        <label for="">Location</label>
        <input type="text" name="lokasi" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" value="Edit" name="Update" class="btn btn-primary">
</div>
    </form>
</div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
    </div>
    </div>
    </div>
    </div>

    <?php endwhile; ?>
    </center>
</body>
</html>

