<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/insta/data/logo.png" type="image/x-icon"> 
    <title>FORM LOGIN</title>
    <link rel="stylesheet" href="style.css">
</head>
 
<body>
 
    <div class="container">
        <div class="login-box">
            <h2>𝓦𝓮𝓵𝓬𝓸𝓶𝓮 𝓢𝓽𝓾𝓭𝓲𝓸 𝓖𝓱𝓲𝓫𝓵𝓲 </h2>
            <form action="proses_login.php" method="post">
                <div class="input-box">
                    <input type="text" name="username" required>
                    <label>Username</label>
                </div>
                <div class="input-box">
                    <input type="password" name="password" required>
                    <label>Password</label>
                </div>
                <button type="submit" value="login"class="btn">Login</button>
            </form>
 
</body>
 
</html>